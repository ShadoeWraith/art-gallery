import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import sharp from 'sharp';

const s3 = new S3Client({});

export const handler = async (event) => {
	const srcBucket = event.Records[0].s3.bucket.name;
	const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));

	// CONFIGURATION
	const dstBucket = srcBucket + '-resized'; // Or hardcode your destination bucket name
	const width = 800; // Target width for web gallery

	try {
		// 1. Download image from Source Bucket
		const response = await s3.send(new GetObjectCommand({ Bucket: srcBucket, Key: srcKey }));
		const stream = response.Body;

		// Convert stream to buffer for Sharp
		const chunks = [];
		for await (const chunk of stream) chunks.push(chunk);
		const buffer = Buffer.concat(chunks);

		// 2. Resize using Sharp
		const resizedBuffer = await sharp(buffer)
			.resize({ width: width })
			.jpeg({ quality: 80 }) // Compress to 80% quality JPEG
			.toBuffer();

		// 3. Upload to Destination Bucket
		await s3.send(
			new PutObjectCommand({
				Bucket: dstBucket,
				Key: `resized-${srcKey}`,
				Body: resizedBuffer,
				ContentType: 'image/jpeg'
			})
		);

		console.log(
			`Successfully resized ${srcBucket}/${srcKey} and uploaded to ${dstBucket}/resized-${srcKey}`
		);
	} catch (error) {
		console.error('Error processing image: ', error);
		throw error;
	}
};
